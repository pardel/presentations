# "What Developers Want"
A talk I've given at apidays Live Paris in December 2021.

Sharing the learnings I’ve accumulated over the last 3 years whilst working with developers using Vonage products. And some practical takeaways...

- [Slides](apidaysParis_What-developers-want.pdf)
- [Video](https://www.youtube.com/watch?v=4O92wtjpCLU)
